<aside>
    <div id="sidebar" class="nav-collapse">
        <!-- sidebar menu start-->
        <div class="leftside-navigation">
            <ul class="sidebar-menu" id="nav-accordion">
                <li>
                    <a class="active" href="dashboard.php">
                        <i class="fa fa-dashboard"></i>
                        <span>Dashboard</span>
                    </a>
                </li>
                
               

<li class="sub-menu">
                    <a href="javascript:;">
                        <i class="fa fa-th"></i>
                        <span>List Your PG</span>
                    </a>
                    <ul class="sub">
                        <li><a href="add-pgdetails.php">Add PG</a></li>
                        <li><a href="manage-pgdetails.php">Manage PG</a></li>
                    </ul>
                </li>
                                
                             <li>
                    <a  href="new-bookingrequest.php">
                        <i class="fa fa-files-o"></i>
                        <span>Booking Requests</span>
                    </a>
                    <ul class="sub">
                        <li><a href="new-bookingrequest.php">New Booking</a></li>
                        <li><a href="confirmed-pgbooking.php">Confirm Booking</a></li>
                        <li><a href="cancelled-pgbooking.php">Cancelled Booking</a></li>
                    </ul>
                </li>
                         <li>
                    <a class="active" href="search.php">
                        <i class="fa fa-search"></i>
                        <span>Search</span>
                    </a>
                </li>
              
                
            </ul>            </div>
        <!-- sidebar menu end-->
    </div>
</aside>