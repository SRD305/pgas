<?php
session_start();
error_reporting(0);
include('includes/dbconnection.php');
?>

		<div class="container">
			<div class="row">
				<div class="col-lg-3 col-md-6 col-sm-6">
				
						<h6><?php  echo $row['PageTitle'];?></h6>
						<p><?php  echo $row['PageDescription'];?></p>
						<?php } ?>

					</div>
				</div>




			</div>


			</div>
		</div>
	</footer>
