<?php
$con=mysqli_connect("db4free.net:3306 ", "sthouse", "12345678", "sthouse");
if(mysqli_connect_errno()){
echo "Connection Fail".mysqli_connect_error();
}

?>
  //<?php
  //$con=mysqli_connect("student-housing-274815:europe-west1:student-house ", "root", "Aaditya@01", "sthouse");
  //if(mysqli_connect_errno()){
  //echo "Connection Fail".mysqli_connect_error();
  //}

    //?>
