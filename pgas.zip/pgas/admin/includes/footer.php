<div class="footer">
			<div class="wthree-copyright">
			  
			</div>
		  </div>
