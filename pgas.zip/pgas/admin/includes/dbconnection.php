<?php
$con=mysqli_connect("db4free.net:3306 ", "sthouse", "12345678", "sthouse");
if(mysqli_connect_errno()){
echo "Connection Fail".mysqli_connect_error();
}

  ?>
